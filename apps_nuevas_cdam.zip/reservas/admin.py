from django.contrib import admin
from .models import Cliente, Reserva, BloqueoFecha


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ("nombre", "email", "telefono", "convenio", "creado_en")
    search_fields = ("nombre", "email", "telefono")
    list_filter = ("convenio",)


@admin.register(Reserva)
class ReservaAdmin(admin.ModelAdmin):
    list_display = ("cliente", "tipo_sesion", "modalidad", "fecha", "hora", "estado")
    list_filter = ("estado", "tipo_sesion", "modalidad")
    search_fields = ("cliente__nombre", "cliente__email")
    date_hierarchy = "fecha"
    actions = ["marcar_confirmada", "marcar_cancelada"]

    @admin.action(description="Marcar como confirmada")
    def marcar_confirmada(self, request, queryset):
        queryset.update(estado=Reserva.ESTADO_CONFIRMADA)

    @admin.action(description="Marcar como cancelada")
    def marcar_cancelada(self, request, queryset):
        queryset.update(estado=Reserva.ESTADO_CANCELADA)


@admin.register(BloqueoFecha)
class BloqueoFechaAdmin(admin.ModelAdmin):
    list_display = ("fecha", "motivo")
